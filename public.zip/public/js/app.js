$(document).ready(function(){
    $.get("../data.json", function(data, status){
      renderProduct(data.products);
      console.log(data);
      $('#checkPin').on('click',function(e){
			console.log(e.target.value);
			checkAvailibility(document.getElementById('checkPinVal'),data.pincode);
		}) 
    });
})

function checkAvailibility(val,pin){
	if(Object.keys(pin).indexOf(val.value)==-1){
		console.log('no');
	}else{
		for(var ii in pin){
			if(ii == val.value){
				var str = '';
				if(pin[ii].cashOnDelivery){
					str +='<img src="assets/icon/check.png">Cash on Deliverry Available<br/>';
				}else{
					str +='<img src="assets/icon/check.png">Cash on Deliverry Not Available<br/>';
				}

				if(pin[ii].deliveryPrice>0){
					str +='<img src="assets/icon/check.png">Deliverry Price = '+pin[ii].deliveryPrice+'<br/>';
				}else{
					str +='No Deliverry Price<br/>';
				}
				if(pin[ii].estimatedDays){
					str +='<img src="assets/icon/check.png">Estimated Delivery Time is Between '+pin[ii].estimatedDays.min+'-'+pin[ii].estimatedDays.max+'Days';
				}
			}
		}
	}
	console.log(str);
	document.getElementById('deleveryStatus').innerHTML = str;
}
function renderProduct(products){
	console.log(products);
	console.log(extractItemData(products));
	$('#items').html(extractItemData(products));
}

function extractItemData(products){
	var str = '';
	products.forEach(function(itm){
		str+='<tr>'
		str +='<td class="flex img-desc"><div style="max-width: 170px;"><img src="'+itm.imageUrl+'"></div><div>';
		str +='<ul class="list-unstyled"><li>';
		str+=itm.tagline+'</li><li>';
		str+=itm.name+'</li><li>';
		str+=itm.desc+'</li></ul></div></td>'


		str+='<td>'+itm.price+'$</td>';
		str+='<td>-<input type="number">+</td>';
		str+='<td id="'+itm.id+'">'+itm.price+'$</td>';
		str+='<td><img src="assets/icon/DELETE.png"></td>';
	})
	return str;
}

